export interface SubmitFormRequestData {
  username: string;
}
