export interface CheckUserResponseData {
  isAvailable: boolean;
}

export interface SubmitFormResponseData {
  result: string;
}
