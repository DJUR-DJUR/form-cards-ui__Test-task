export enum Country {
  Ukraine = 'Ukraine',
  Poland = 'Poland',
  Australia = 'Australia',
  Austria = 'Austria',
  Nepal = 'Nepal',
  USA = 'USA',
  Mexico = 'Mexico',
}
