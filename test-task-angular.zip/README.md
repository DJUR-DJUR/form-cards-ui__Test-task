## Starting the App

Run `npm i` to install dependencies first, and then run `ng s` to start the app.
